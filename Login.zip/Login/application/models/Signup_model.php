<!-- 
==========================================
 Title:  Signup_model
 Author: Chetan Thakare
 Date:   22 Mar 2017
========================================== -->
<?php
class Signup_model extends CI_Model {
    
        /* add data to the database */
    public function add($data) {
        $this->db->insert('login',$data); }

        /* get details from database */
    public function get_details() {
            $this->db->select('*');
            $this->db->from('login');
            $get =  $this->db->get();
            return $get->result(); }

        /* by passing id edit record */
    public function edit_record($user_id) {
        $this->db->where('user_id',$user_id);
        $query =  $this->db->get('login');
        return $query->row(); }

        /* check username exist or not */
    public function check_user_exist($username){
        $this->db->where('username',$username);
        $this->db->from('login');
        $query = $this->db->get();
        if($query->num_rows()>0){
            return $query->result(); }
        else{
            return $query->result(); } }

        /* check mail exist or not */
      public function check_email_exist($email){
        $this->db->where('email',$email);
        $this->db->from('login');
        $query = $this->db->get();
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return $query->result();
            //return false;    
        } }
}
?>