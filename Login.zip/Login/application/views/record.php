<!-- 
==========================================
 Title:  Record View
 Author: Chetan Thakare
 Date:   22 Mar 2017
========================================== -->
<head>    
    <title> View Record </title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<!-- set flash data-->
 <?php if($this->session->flashdata('message')){?>
  <div class="alert alert-success">      
    <?php echo $this->session->flashdata('message')?>
  </div> <?php } ?>
</br></br>
<div class="row">
    <div class="col-sm-offset">
    <div class="col-sm-1">
    </div>
   <!-- <div class="row"> -->
       <div class="col-sm-8">
            <div class="table-hover-offset">
                <table class="table table-hover">
                    <thead><!-- table head-->
                        <th>User Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Username</th>
                        <th>Delete</th>
                        <th>Edit</th>
                        <th>Status</th>
                    </thead>
                    <tbody>
                        <?php foreach($this->sm->get_details() as $row) {?><!-- get data from database-->
                        <tr>
                        <td><?php echo $row->user_id;?></td>
                        <td><?php echo $row->name;?></td>
                        <td><?php echo $row->email;?></td>
                        <td><?php echo $row->username;?></td>
                        <!-- for delete record from database-->
                        <td><?php echo anchor("SignupController/delete/".$row->user_id,"Delete",array('onclick' => "return confirm('Do you want delete this record')"))?></td>
                        <!-- for edit record from database-->
                        <td><a href="<?php echo site_url('SignupController/edit/'.$row->user_id);?>">Edit</a></td>
                        <td><?php if($row->status ==0){echo'Active';} else { echo'Inactive';} ?></td>
                        </tr>
                        <?php }?>
                    </tbody>
                </table>
                <a href="<?php echo site_url("Login/logout");?>">
                <input type="button" class="btn btn-primary" value="Logout"></a>
            </div>
        </div>
    </div>
</div>    
</body>
</html>