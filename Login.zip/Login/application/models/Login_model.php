<!-- 
==========================================
 Title:  Login Model
 Author: Chetan Thakare
 Date:   22 Mar 2017
========================================== -->
<?php
class Login_model extends CI_Model {
    public function process(){
       
       $name     = $this->input->post('name');
       $email    = $this->input->post('email');
       $username = $this->input->post('username');
       $password = $this->input->post('password');
      
       if($username == 'chetan' && $password == '123'){
        $data['username'] = $username;
        $this->session->set_userdata(array('username'=>$username));
        $this->load->view('welcome', $data);}
       else{
        $data['error'] = 'Account Is Invalid';
        $this->load->view('login', $data);} }

    /* logout and end session */
    public function logout(){
        $this->session->unset_userdata('username');
        redirect('login');
        $this->session->set_userdata(array('username'=>$username));}

    /* select user from database */
    public function selectUser($username, $password) {
      $this->db->select('*');
      $this->db->from('login');
      $this->db->where('username',$username);
      $this->db->where('password',$password);
      $query = $this->db->get();
      return $query->num_rows();}
    
}
?>