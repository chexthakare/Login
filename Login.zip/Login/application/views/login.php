
<!-- 
==========================================
 Title:  Login View
 Author: Chetan Thakare
 Date:   22 Mar 2017
========================================== -->
<html xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en'>
<head>    
    <title> Login Screen | Welcome </title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<!-- set flash data-->
<div>
    <?php if($this->session->flashdata('message')){?>
      <div class="alert alert-success">      
        <?php echo $this->session->flashdata('message')?>
      </div> <?php } ?>
</div>

<?php echo isset($error) ? $error:'' ?>
    <?php echo form_open('login/check')?>
    </br>
    <div class="row">
        <div class="col-sm-offset">
        <div class="col-sm-1">
        </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <label>Username:</label>
                    <input type="text" name="username" class="form-control" id="username" required>
                </div>

                <div class="form-group">
                    <label>Password:</label>
                    <input type="password" name="password" class="form-control" id="password" required>
                </div>
                <div class="checkbox">
                    <label><input type="checkbox" required> Remember me</label>
                </div>

                <div class="form-group">
                    <input type="submit" class="btn btn-default" value="Login">
                    <a href="<?php echo site_url("SignupController");?>">
                    <input type="button" class="btn btn-primary" value="SignUp"></a>
                </div>

            </div>  
        </div>
    </div>
</body>
</html>

