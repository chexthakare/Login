<!-- 
==========================================
 Title:  Home Controler
 Author: Chetan Thakare
 Date:   22 Mar 2017
========================================== -->
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

 class Home extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->check_isvalidated();
    }
    
    public function index(){
        // If the user is validated, then this function will run
        echo 'Congratulations, you are logged in.';
    }
     // chek whether is it valid or not
    private function check_isvalidated(){
        if(! $this->session->userdata('validated')){
            redirect('Login');
        }
    }
     // function for logout
	public function do_logout(){
        $this->session->sess_destroy();
        redirect('Login');
    }
 }
 ?>