<!-- 
==========================================
 Title:  Invalid View
 Author: Chetan Thakare
 Date:   22 Mar 2017
========================================== -->

<html xmlns="http://www.w3.org/1999/xhtml">
 <head><title>Simple Login with CodeIgniter - Private Area</title>
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
 </head>
 <body></br></br>
    <div class="row">
        <div class="col-sm-offset">
	        <div class="col-sm-1">
	        </div>
        <div class="col-sm-5">
		   <h4 style="color:red;">Invalid Username and Password</h4><br>
		   <?php echo anchor('Login','Go Back');?>
		</div>
   		
   </div>
 </body>
</html>