<!-- 
==========================================
 Title:  SignUp Screen
 Author: Chetan Thakare
 Date:   22 Mar 2017
========================================== -->
<html xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en'>
<head>    
    <title> SignUp Screen | Welcome </title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <style type="text/css">
    /* visited link */
    a:visited {
    color: white; }

    /* mouse over link */
    a:hover {
    color: yellow; }

    /* selected link */
    a:active {
    color: white; }
    </style>
</head>
<body>
<!-- set flash data-->
 <?php if($this->session->flashdata('message')){?>
  <div class="alert alert-danger">      
    <?php echo $this->session->flashdata('message')?>
  </div> <?php } ?>

    </br>
    <div class="row">
        <div class="col-sm-offset">
            <div class="col-sm-1">
            </div>
            <div class="col-sm-3">
            <form name="form" method="POST" action="<?php if(isset($r)){ echo site_url('SignupController/update/'.$r->user_id); } else{ echo site_url('SignupController/save/');}?>">

                <!-- Name -->
                <div class="form-group">
                    <label>Name:</label>
                    <input type="text" name="name" class="form-control" id="name" value="<?php if(isset($r)) echo $r->name; ?>" required>
                </div>

                <!-- Email -->
                <div class="form-group">
                    <label>Email:</label>
                    <input type="email" name="email" class="form-control" id="email" value="<?php if(isset($r)) echo $r->email; ?>" required>
                </div>

                <!-- username -->
                <div class="form-group">
                    <label>Username:</label>
                    <input type="text" name="username" class="form-control" id="username" value="<?php if(isset($r)) echo $r->username; ?>" required>
                    <span id="uname_result"></span>
                </div>
                <!-- password -->
                <div class="form-group">
                    <label>Password:</label>
                    <input type="password" name="password" class="form-control" id="password" value="<?php if(isset($r)) echo $r->password; ?>" required>
                </div>

                <div class="col-lm-10">
                    <input type="submit" class="btn btn-primary" value="Submit">
                    <span>&nbsp;&nbsp;already have account?</span>&nbsp;&nbsp;<span class="label label-danger"><a href="<?php echo site_url("Login");?>">Click here</a></span>
                </div>
                </br>
            </form>
            </div>  
        </div>
    </div>
</body>
</html>