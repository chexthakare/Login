<!-- 
==========================================
 Title:  Success View
 Author: Chetan Thakare
 Date:   22 Mar 2017
========================================== -->

<html xmlns="http://www.w3.org/1999/xhtml">
 <head><title>Sucess</title>
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
 </head>
 <body>
 <!-- set flash data-->
<div class="row">
	<div>
	    <?php if($this->session->flashdata('message')){?>
	      <div class="alert alert-success">      
	        <?php echo $this->session->flashdata('message')?>
	      </div> <?php } ?>
	</div>
</div>
</br>
<div class="row">
	<div class="col-sm-offset">
		<div class="col-sm-1">
	    </div>
	    <div class="col-sm-2">
	    	<div><h4><?php echo anchor('Login','Please Proceed to Login');?></h4></div>
		</div>
	</div>
	
</div>   
</body>
</html>