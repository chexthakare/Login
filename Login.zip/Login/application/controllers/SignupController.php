<!-- 
==========================================
 Title:  SignupController
 Author: Chetan Thakare
 Date:   22 Mar 2017
========================================== -->

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 class SignupController extends CI_Controller{
    public function __construct() {
        parent:: __construct();
        $this->load->helper('download');
        $this->load->helper('file');
        $this->load->helper(array('form','url'));
        $this->load->library(array('session', 'form_validation', 'email'));
        $this->load->database();
        $this->load->model('Signup_model','sm');}

      /* load signup view */
    public function index(){
        $this->load->view('signup');}

      /* display sucess page */
    public function success(){
        $this->load->view('success');}

    public function record(){
        $this->load->view('record');}

      /* add records */
    public function add(){
        $data['data'] = 'Insert new user';
        $this->load->view('signup',$data); }

      /* save records */
    public function save() {
        $data =  array(
        'name'     =>$this->input->post('name'),
        'email'    =>$this->input->post('email'),
        'username' =>$this->input->post('username'),
        'password' =>$this->input->post('password'));

        $this->load->model('Signup_model');
          if($this->Signup_model->check_user_exist($data['username'])){
            $this->session->set_flashdata('message', 'This Username is Already Taken!');
            redirect('SignupController');}
          elseif($this->Signup_model->check_email_exist($data['email'])){
            $this->session->set_flashdata('message', 'This Email Already Registered With System');
            redirect('SignupController');}
          else{
            $this->Signup_model->add($data);
            $this->session->set_flashdata('message', 'Record Successfully Added.');
            redirect('SignupController/success'); } }
         
      /*edit record*/
    public function edit($user_id) {
        $this->load->model('sm');
        $data['r'] = $this->sm->edit_record($user_id);
        //print_r($data);
        //exit;
        $this->load->view('signup',$data); }

      /* delete record */
    public function delete($user_id){
        $this->db->where('user_id',$user_id);
        $this->db->delete('login');
        $this->session->set_flashdata('message', 'Successfully Deleted.');
        redirect('SignupController/record'); }

      /* update record from database */ 
    public function update($user_id) {
      $data = array(
        'name'     =>$this->input->post('name'),
        'email'    =>$this->input->post('email'),
        'username' =>$this->input->post('username'),
        'password' =>$this->input->post('password'));
        $this->db->where('user_id',$user_id);
        $this->db->update('login',$data);
        $this->session->set_flashdata('message', 'Successfully Updated.');
        redirect('SignupController/record'); }


        /** logout **/
    public function logout(){
        $this->session->unset_userdata('username');
        redirect('login');
        $this->session->set_userdata(array('username'=>$username));}

  
 }
 ?>