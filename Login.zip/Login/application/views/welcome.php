<!-- 
==========================================
 Title:  Welcome View
 Author: Chetan Thakare
 Date:   22 Mar 2017
========================================== -->
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Welcome</title>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

 </head>
<!--flash message-->
 <?php if($this->session->flashdata('message')){?>
  <div class="alert alert-success">      
    <?php echo $this->session->flashdata('message')?>
  </div> <?php } ?>

 <body>
	 <div class="row">
		<div class="col-sm-7">
			<div class="col-sm-7">
				<!--sent session data-->
			   <h4>Welcome! <?php echo $this->session->userdata('username'); ?></h4>
			</div>
		</div>
	  </div></br>
	<div class="row">
		<div class="col-sm-4">
			<div class="col-sm-4">
			<!--link to edit page-->
	   		<a href="<?php echo site_url("SignupController/record");?>">
	  		<input type="button" class="btn btn-primary" value="Check User"></a>
	  		</div>
	  		<div class="col-sm-4">
	   		<a href="<?php echo site_url("Login/logout");?>">
	  		<input type="button" class="btn btn-primary" value="Logout"></a>
	  		</div>
	  	</div>
	</div>
 </body>
</html>