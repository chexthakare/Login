<!-- 
==========================================
 Title:  Signup_model
 Author: Chetan Thakare
 Date:   22 Mar 2017
========================================== -->
<?php
class user_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    //insert into user table
    function insertUser($data)
    {
        return $this->db->insert('login', $data);
    }
    
}
?>