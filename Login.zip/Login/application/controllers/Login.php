<!-- 
==========================================
 Title:  Login Controler
 Author: Chetan Thakare
 Date:   22 Mar 2017
========================================== -->
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 class Login extends CI_Controller{
    public function __construct()
     {
          parent::__construct();
          $this->load->library('session');
          $this->load->helper('form');
          $this->load->helper('url');
          $this->load->helper('html');
          $this->load->database();
          
          //load the login model
          $this->load->model('Login_model'); 
          $this->load->model('Emp_model','em');}

    /* redirect to login */ 
    public function index(){
       $this->load->view('login'); }

    /* redirect to invalid */ 
   public function invalid(){
        $this->load->view('invalid');}

    /* redirect to invalid */ 
   public function employee(){
        $this->load->view('employee');}     

    /* function for logout */ 
    public function logout(){
        $this->session->unset_userdata('username');
        redirect('login');
        $this->session->set_userdata(array('username'=>$username));}

    /* check valid user */ 
    public function check(){
        $username = $this->input->post("username");
        $password = $this->input->post("password");
        $this->load->model('Signup_model');
        $result  = $this->Login_model->selectUser($username, $password);
                if ($result > 0) //active user record is present
                {
                     //set the session variables
                     $_SESSION['username'] = $username;
                     $this->session->set_flashdata('message', 'Successfully Login.');
                     $this->load->view('welcome',$username);
                }
                else
                {
                     redirect('Login/invalid');
                } }
        

    
 }
 ?>